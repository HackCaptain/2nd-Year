/*
	Desc: Skeleton code for a basic scrolling example
	
	Author: Lynsay A. Shepherd
	
	Date: October 2016
*/

/*Edited by P.Captain*/


window.onload = prepPage;

function prepPage()
{
	//example of using JavaScript to append a placeholder div to the page
	
	//// Edit This 
	
	var placeholder = document.createElement("div");
	placeholder.setAttribute("id", "placeholder");
    placeholder.style.width = "200px";
    placeholder.style.height = "230px";
    placeholder.style.overflow = "hidden";
    placeholder.style.position = "centre";
	
	var instrumentImage = document.createElement("img");
	instrumentImage.setAttribute("id", "instrumentImage");
	instrumentImage.setAttribute("src", "instruments.jpg");
    instrumentImage.setAttribute("alt", "instrument");
    instrumentImage.style.position = "absolute";
    instrumentImage.style.left = "0px";
	
	placeholder.appendChild(instrumentImage);
	
	var instrumentlist = document.getElementById("instrumentlist");
    instrumentlist.parentNode.insertBefore(placeholder, instrumentlist);
    instrumentlist.style.margin = "auto";
    
    var instrument = instrumentlist.getElementsByTagName("li");
    
    for(var i=0; i<instrument.length; i++)
    {
		instrument[i].onmouseover = new Function("moveElement('instrumentImage', " + -i*226 + ")");
    }
}

function moveElement(element, targPos)
{
	var el = document.getElementById(element);
	var currPos = parseInt(el.style.left.replace("px", ""));

	if(el.movement) clearTimeout(el.movement);
	
	if(currPos == targPos) return;
	else if(currPos > targPos) currPos-=2;
	else currPos+=2;
	
	el.style.left = currPos + "px";
	
	var repeat = "moveElement('"+ element +"', '"+ targPos +"')";
	el.movement = setTimeout(repeat, 1);
}
