<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style_d.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Hi, </b>. Welcome ADMIN.</h1>
    </div> 
	
	<?php
define('DB_SERVER', 'lochnagar.abertay.ac.uk');
define('DB_USERNAME', 'sql1800326');
define('DB_PASSWORD', 'ktwmprdcwGnN');
define('DB_NAME', 'sql1800326');

/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "SELECT id, username, isadmin FROM users";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["username"]. " is admin " . $row["isadmin"]. "<br>";
    }
} else {
    echo "0 results";
}

/*
$result = mysql_query("SHOW COLUMNS FROM users") or die("cannot show columns from users");


	echo '<table cellpadding="0" cellspacing="0" class="db-table">';
		echo '<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default<th>Extra</th></tr>';
		while($row = $result->fetch_assoc()) {
			echo '<tr>';
			foreach($row as $key=>$value) {
				echo "id: " . $row["id"]. " - Name: " . $row["username"]. " is admin " . $row["isadmin"]. "<br>";echo '<td>',$value,'</td>';
			}
			echo '</tr>';
		}
		echo '</table><br />';
*/


$link->close();
?>

    <p>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>



	    <button type="button" class="btn btn-danger"><a href="register.php">
		<p class ="text"> CREATE USER</p>
		</button>
	
	    <button type="button" class="btn btn-danger"><a href="delete.php">
		<p class ="text"> DELETE USER</p>
		</button>
	
</div>
</body>
</html>