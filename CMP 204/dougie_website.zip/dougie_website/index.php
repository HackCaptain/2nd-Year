<?php
	header("location: dougster_homepage.html");
?>