/*
	Desc: Skeleton code for adding a clock to a web page
	
	Author: Lynsay A. Shepherd
	
	Date: September 2016
*/


window.onload = function()
{
	//this function is called when the web page is loaded
	//1 second increments
	setTime();
	setInterval("setTime()", 1000);
}



function setTime()
{
	//you'll need to use getElementById and innerHTML to select the time div
	//then call the getTime() function
	
}




function getTime()
{

	//date and time functions you might want to look at- getHours etc.
	
	
}