<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Requirements page</title>
	<link rel="stylesheet" href="reqStyle.css">
</head>
<body>

<h1>CMP204 Requirements Page</h1>

<p>If you have not met a requirement, do not delete it from the table.</p>

<table>
  <tr>
    <th class="reqCol">Requirement</th>
    <th class="metCol">How did you meet this requirement?</th>
    <th class="fileCol">File name(s), line no.</th>
  </tr>
  <tr>
    <td>A clear use of HTML5</td>
    <td>See all .html pages. Eg. dougster_homepage/news/about/merchandise</td>
	<td></td>
  </tr>
  <tr>
    <td>Use of the Bootstrap framework providing a responsive layout </td>
    <td>See all .html pages and resize the page ***********</td>
	<td></td>
  </tr>
  <tr>
    <td>Use of JavaScript to manipulate the DOM based on an event</td>
    <td> ***Timer?*** dougster_news.html</td>
	<td></td>
  </tr>
  <tr>
    <td>JavaScript loading of dynamically changing information</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>Use of jQuery in conjunction with the DOM</td>
    <td>Different things throughout the website such as pagetop where mouseover changes bg colour, Sliders</td>
	<td></td>
	</tr>
  <tr>
    <td>Use of a jQuery plugin to enhance your application</td>
    <td>Look at custom code, perhaps the store once its completed or even the calander function for the event date</td>
    <td></td>
  </tr>
  <tr>
    <td>Use of AJAX (pure JavaScript i.e. without the use of a library)</td>
    <td>The page top script </td>
	<td></td>
  </tr>
  <tr>
    <td>Use of the jQuery AJAX function</td>
    <td>Perhaps it could load the store</td>
	<td></td>
  </tr>
  <tr>
    <td>User login functionality (PHP/MySQL)</td>
    <td>Yes on the library/contact page</td>
	<td></td>
  </tr>
  <tr>
    <td>Admin section of the website (PHP/MySQL)</td>
    <td>Yes, when logged in as test, test123</td>
	<td></td>
  </tr>
  <tr>
    <td>Ability to select, add, edit and delete information from a database (PHP/MySQL)</td>
    <td> Through the admin web page</td>
	<td></td>
  </tr>
  <tr>
    <td>Appropriate consideration of relevant laws</td>
    <td> See the click here to see gdpr laws underneath register</td>
	<td></td>
  </tr>
  <tr>
    <td>Security measures</td>
    <td> . It also checks if user is already logged in</td>
	<td></td>
  </tr>
  <tr>
    <td>SQL queries should be written as prepared statements</td>
    <td> Yes they are, when a user inputs their username</td>
	<td></td>
  </tr>
  <tr>
    <td>Passwords should be salted and hashed</td>
    <td>Login page uses php prepared statements and hashes and salts new passwords</td>
	<td></td>
  </tr>
  <tr>
    <td>Validation of user input</td>
    <td> When user inputs username a prepared statement checks the username and password with that of the stored username and hashed password.</td>
    <td></td>
  </tr>
  
  <tr>
    <td>Any other relevant security features</td>
    <td> Login page checks if user has already been logged in</td>
	<td></td>
  </tr>
</table>
		
</body>
</html>



