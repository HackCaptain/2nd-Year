<?php
require_once "config.php";

$targetid = "";


// sql to delete a record



if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	/* Delete Target ID
    if(empty(trim($_POST["targetid"]))){
        $targetid_err = "Please enter an ID to delete.";
    } else{
        // Prepare a select statement
     $sql = "DELETE FROM users WHERE id= targetid" ;
	} */
	
	
	if ($link->query($sql) === TRUE) {
		echo "Record deleted successfully";
	} else {
		echo "Error deleting record: " . $link->error;
	}
	
	// Close statement
    mysqli_stmt_close($stmt);
}


$link->close();
?>

<DOCTYPE html>
<html lang="en">
<head>
  <title>Delete User </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style_d.css">
</head>

<body>

<div class="form-group ">
                <label>Target Id</label>
                <input type="text" name="targetid" class="form-control" value="">
                <span class="help-block"></span>
            </div>
			
			<div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>

	    <p>Back to Admin Page <a href="adminpage.php">Click here</a>.</p>

</body>
