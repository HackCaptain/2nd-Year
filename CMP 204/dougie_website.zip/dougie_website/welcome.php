<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: dougster_contact.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style_d.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to your library.</h1>
    </div>
	 
    <p>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>
	
			<div class="container">
  <div class="row">
    <div class="col-sm-4">
		<iframe src="https://open.spotify.com/embed/artist/63gizE0cqalXVpwZdZHY47" width="300" height="380" frameborder="0" padding-left="50px" allowtransparency="true" allow="encrypted-media"></iframe>
        </div>
    <div class="col-sm-4">
		<iframe src="https://open.spotify.com/embed/album/5526cc5QEwnSkNzcG7R5RA" width="300" height="380" frameborder="0" padding-left="50px" allowtransparency="true" allow="encrypted-media"></iframe>
	    </div>
    <div class="col-sm-4">      
		<iframe src="https://open.spotify.com/embed/album/7IyDUiH6CvYtlDt11hs0D6" width="300" height="380" frameborder="0" padding-left="50px" allowtransparency="true" allow="encrypted-media"></iframe>
    </div>
	
</div>
</body>
</html>